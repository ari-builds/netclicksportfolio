# Ari's Expanded Portfolio

I need you to look at my portfolio website: https://ari-builds.github.io/netclicksportfolio/ keep everything it has just add stuff look at all the services, all of these services need their own seperate website page utilize framer motions, 21st.dev, and the ui/ux design skill you can go on github to find them i think, and this is = to make sure these pages are beautiful just like the existing pages and then push the code to this so that when I go to this link, I see the changes. Don't alter the rest of the site though.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/a1c5fabc-ddb1-4ffe-9675-d5d5c05293af).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
