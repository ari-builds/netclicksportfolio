import ServicePage from "../ServicePage"
import { services } from "../ServiceConfig"
import { serviceExtras } from "../ServiceExtras"
import { ProcessTimeline, Deliverables, PricingTiers, FAQ } from "../ServiceSections"

const service = services.find(s => s.slug === "svc-seo")
const extras = serviceExtras["svc-seo"]

export default function SeoPage() {
  const c = service.color
  const scrollToCta = () => document.getElementById("demo")?.scrollIntoView({ behavior: "smooth" })
  return (
    <ServicePage service={service}>
      <ProcessTimeline steps={extras.process} color={c} subtitle={`Our proven ${service.title.toLowerCase()} engagement, step by step.`} />
      <Deliverables items={extras.deliverables} color={c} />
      <PricingTiers tiers={extras.pricing} color={c} onSelect={scrollToCta} />
      <FAQ items={extras.faq} color={c} />
    </ServicePage>
  )
}
