import WebDesignPage from "./svc-web-design/page"
import WebDevPage from "./svc-web-dev/page"
import EcommercePage from "./svc-ecommerce/page"
import SeoPage from "./svc-seo/page"
import ResponsivePage from "./svc-responsive/page"
import PerformancePage from "./svc-performance/page"
import LeadGenPage from "./svc-leadgen/page"
import OutreachPage from "./svc-outreach/page"
import AiAutomationPage from "./svc-ai-auto/page"
import SocialPage from "./svc-social/page"
import VoicePage from "./svc-voice/page"
import WorkflowsPage from "./svc-workflows/page"
import ContentPage from "./svc-content/page"
import AnalyticsPage from "./svc-analytics/page"
import MaintenancePage from "./svc-maintenance/page"
import MobilePage from "./svc-mobile/page"
import ApiPage from "./svc-api/page"

export const servicePages = {
  "svc-web-design": WebDesignPage,
  "svc-web-dev": WebDevPage,
  "svc-ecommerce": EcommercePage,
  "svc-seo": SeoPage,
  "svc-responsive": ResponsivePage,
  "svc-performance": PerformancePage,
  "svc-leadgen": LeadGenPage,
  "svc-outreach": OutreachPage,
  "svc-ai-auto": AiAutomationPage,
  "svc-social": SocialPage,
  "svc-voice": VoicePage,
  "svc-workflows": WorkflowsPage,
  "svc-content": ContentPage,
  "svc-analytics": AnalyticsPage,
  "svc-maintenance": MaintenancePage,
  "svc-mobile": MobilePage,
  "svc-api": ApiPage,
}
