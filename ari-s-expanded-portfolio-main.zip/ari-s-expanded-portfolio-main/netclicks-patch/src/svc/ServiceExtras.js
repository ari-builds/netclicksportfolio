// Per-service page content: unique process, deliverables, pricing and FAQ
// for each dedicated service page.
export const serviceExtras = {
  "svc-web-design": {
    process: [
      { step: "Brand Immersion", desc: "We audit your current identity, competitors, and audience to define a visual point of view." },
      { step: "Wireframe Sprint", desc: "Low-fidelity flows and layouts approved before a single pixel is polished." },
      { step: "High-Fidelity Design", desc: "Full component library, typography scale, motion notes and responsive states." },
      { step: "Handoff & QA", desc: "Developer-ready Figma files, tokens, and a design QA pass on the live build." },
    ],
    deliverables: ["Figma design system", "Desktop + mobile screens", "Clickable prototype", "Motion spec", "Accessibility report"],
    pricing: [
      { tier: "Landing", price: "$2.4K", blurb: "One high-converting page", items: ["1 page design", "2 revision rounds", "Mobile + desktop"] },
      { tier: "Site", price: "$6.8K", blurb: "Full marketing site", items: ["Up to 8 pages", "Design system", "Prototype + handoff"], featured: true },
      { tier: "Product", price: "Custom", blurb: "App or platform UI", items: ["Unlimited screens", "Component library", "Ongoing design partner"] },
    ],
    faq: [
      { q: "How long does a design project take?", a: "A landing page runs 1–2 weeks; a full marketing site is typically 3–5 weeks from kickoff to handoff." },
      { q: "Do you work from our brand guidelines?", a: "Yes. If you have guidelines we extend them; if you don't, we build a lightweight system as part of the project." },
      { q: "What if we don't like the direction?", a: "We present two directions after the wireframe sprint, and every package includes revision rounds before build." },
    ],
  },
  "svc-web-dev": {
    process: [
      { step: "Technical Discovery", desc: "Stack selection, data model, integrations and performance budgets agreed up front." },
      { step: "Foundation Build", desc: "Repo, CI/CD, component architecture and design tokens wired in week one." },
      { step: "Feature Sprints", desc: "Weekly deployable increments on a staging URL you can click through anytime." },
      { step: "Launch & Handover", desc: "Load testing, monitoring, documentation and a walkthrough with your team." },
    ],
    deliverables: ["Production codebase", "CI/CD pipeline", "Staging + prod environments", "Technical docs", "30-day post-launch support"],
    pricing: [
      { tier: "Build", price: "$4.5K", blurb: "Marketing site build", items: ["Design to code", "CMS wiring", "Analytics setup"] },
      { tier: "Application", price: "$14K", blurb: "Full-stack web app", items: ["API + database", "Auth & roles", "Admin dashboard"], featured: true },
      { tier: "Platform", price: "Custom", blurb: "Multi-tenant systems", items: ["Scalable architecture", "SLA + monitoring", "Dedicated team"] },
    ],
    faq: [
      { q: "Do we own the code?", a: "Completely. Everything ships to your repository under your organisation from day one." },
      { q: "Which stack do you use?", a: "React, Next.js or Vite on the frontend; Node, Python or serverless on the backend — chosen to fit your team." },
      { q: "Can you take over an existing codebase?", a: "Yes. We start with an audit sprint and a prioritised remediation plan before shipping features." },
    ],
  },
  "svc-ecommerce": {
    process: [
      { step: "Revenue Audit", desc: "We map your funnel, AOV, and drop-off points to find the highest-leverage fixes first." },
      { step: "Store Architecture", desc: "Catalog structure, merchandising rules and checkout flow designed around conversion." },
      { step: "Build & Integrate", desc: "Payments, shipping, tax, inventory and marketing automations wired end to end." },
      { step: "Optimise", desc: "A/B testing on PDPs, cart and checkout with monthly revenue reporting." },
    ],
    deliverables: ["Storefront build", "Checkout optimisation", "Abandoned cart flows", "Inventory sync", "Revenue dashboard"],
    pricing: [
      { tier: "Launch", price: "$5.9K", blurb: "New store, fast", items: ["Up to 100 SKUs", "Payments + shipping", "Email flows"] },
      { tier: "Growth", price: "$12K", blurb: "Scale existing revenue", items: ["Custom PDP/checkout", "CRO testing", "Loyalty + upsells"], featured: true },
      { tier: "Enterprise", price: "Custom", blurb: "Multi-brand catalogs", items: ["Headless build", "ERP integration", "Dedicated support"] },
    ],
    faq: [
      { q: "Shopify or custom?", a: "Shopify for speed to market, headless or custom when catalog complexity or margins justify it. We advise honestly." },
      { q: "Can you migrate our existing store?", a: "Yes — products, customers, orders and SEO redirects are migrated with zero ranking loss." },
      { q: "Do you handle ongoing CRO?", a: "Growth and Enterprise include a monthly testing roadmap with reported revenue impact." },
    ],
  },
  "svc-seo": {
    process: [
      { step: "Technical Audit", desc: "Crawl, index, Core Web Vitals and schema analysis with a prioritised fix list." },
      { step: "Keyword Architecture", desc: "Intent-mapped clusters that match your funnel, not just search volume." },
      { step: "Content & Links", desc: "Publishing calendar plus white-hat digital PR that earns real authority." },
      { step: "Measure & Compound", desc: "Monthly reporting on rankings, traffic value and pipeline contribution." },
    ],
    deliverables: ["Technical audit doc", "Keyword map", "Content calendar", "Backlink campaign", "Monthly rank reporting"],
    pricing: [
      { tier: "Audit", price: "$1.8K", blurb: "One-time deep audit", items: ["Full technical crawl", "Keyword gap analysis", "90-day roadmap"] },
      { tier: "Growth", price: "$2.9K/mo", blurb: "Ongoing organic growth", items: ["4 content pieces/mo", "On-page optimisation", "Link outreach"], featured: true },
      { tier: "Authority", price: "Custom", blurb: "Competitive markets", items: ["Digital PR", "Programmatic SEO", "Dedicated strategist"] },
    ],
    faq: [
      { q: "How fast will we see results?", a: "Technical wins land in weeks; competitive rankings typically move meaningfully between months 3 and 6." },
      { q: "Do you guarantee rankings?", a: "No credible agency can. We do commit to a transparent roadmap and reporting on traffic value, not vanity metrics." },
      { q: "Do you write the content?", a: "Yes — briefed by keyword research, written by specialists, reviewed against E-E-A-T guidelines." },
    ],
  },
  "svc-responsive": {
    process: [
      { step: "Device Matrix", desc: "We define the real devices your audience uses from your analytics, not guesswork." },
      { step: "Fluid Systems", desc: "Type scales, spacing and grid rules that reflow cleanly at every breakpoint." },
      { step: "Cross-Browser QA", desc: "Manual and automated testing across browsers, OS versions and orientations." },
      { step: "Performance Pass", desc: "Adaptive images, lazy loading and budgets enforced per device class." },
    ],
    deliverables: ["Responsive audit", "Breakpoint system", "Device QA report", "Touch target fixes", "Performance budget"],
    pricing: [
      { tier: "Audit", price: "$1.2K", blurb: "Find what's broken", items: ["12-device test pass", "Annotated screenshots", "Fix priority list"] },
      { tier: "Retrofit", price: "$4.2K", blurb: "Fix an existing site", items: ["Full breakpoint rebuild", "Touch optimisation", "Re-test + sign off"], featured: true },
      { tier: "Ongoing", price: "Custom", blurb: "Continuous QA", items: ["Monthly device sweeps", "Regression testing", "Priority fixes"] },
    ],
    faq: [
      { q: "Which devices do you test on?", a: "Real hardware for the top devices in your analytics, plus an emulated matrix covering everything above 1% of traffic." },
      { q: "Is mobile-first always right?", a: "For most audiences yes, but we follow your data — some B2B tools are genuinely desktop-dominant." },
      { q: "Will this affect SEO?", a: "Positively. Mobile usability and layout stability are direct ranking inputs." },
    ],
  },
  "svc-performance": {
    process: [
      { step: "Baseline Profiling", desc: "Lab and field data captured so every improvement is measured against reality." },
      { step: "Critical Path Fixes", desc: "Render-blocking resources, fonts, hydration and image pipelines addressed first." },
      { step: "Infrastructure Tuning", desc: "Caching, CDN rules, compression and edge delivery configured properly." },
      { step: "Guardrails", desc: "Budgets and CI checks so performance never silently regresses again." },
    ],
    deliverables: ["Lighthouse baseline", "Core Web Vitals fixes", "Image pipeline", "CDN/caching config", "CI performance budget"],
    pricing: [
      { tier: "Sprint", price: "$2.2K", blurb: "One-week tune-up", items: ["Audit + quick wins", "Image optimisation", "Before/after report"] },
      { tier: "Overhaul", price: "$6.5K", blurb: "Deep optimisation", items: ["Bundle refactor", "Edge caching", "CI budgets"], featured: true },
      { tier: "Managed", price: "Custom", blurb: "Always fast", items: ["Real-user monitoring", "Monthly tuning", "Alerting + SLAs"] },
    ],
    faq: [
      { q: "What gains are realistic?", a: "Most sites we take on move from 40–60 to 90+ on mobile Lighthouse, with LCP cut by half or more." },
      { q: "Will this break anything?", a: "Every change ships behind staging QA and a rollback plan. Nothing goes live unverified." },
      { q: "Does speed really affect revenue?", a: "Consistently. Sub-second improvements in LCP typically lift conversion in the mid-single digits." },
    ],
  },
  "svc-leadgen": {
    process: [
      { step: "ICP Definition", desc: "We define firmographics, triggers and disqualifiers so volume never beats quality." },
      { step: "Source Engineering", desc: "Custom scrapers, Maps mining and directory pipelines built for your exact criteria." },
      { step: "Enrichment", desc: "Emails, phone numbers, tech stack and intent signals appended and verified." },
      { step: "Delivery", desc: "Clean, deduped leads pushed straight into your CRM on a schedule." },
    ],
    deliverables: ["ICP scorecard", "Custom scrapers", "Verified contact data", "CRM pipeline", "Weekly lead drops"],
    pricing: [
      { tier: "Starter", price: "$900/mo", blurb: "Steady pipeline", items: ["500 verified leads", "Basic enrichment", "CSV + CRM push"] },
      { tier: "Scale", price: "$2.4K/mo", blurb: "High-volume sourcing", items: ["2,500 verified leads", "Full enrichment", "Intent signals"], featured: true },
      { tier: "Custom", price: "Custom", blurb: "Niche or global", items: ["Bespoke sources", "Multi-market", "Dedicated engineer"] },
    ],
    faq: [
      { q: "How accurate is the data?", a: "Every email is verified before delivery; we credit back anything that bounces above a 3% threshold." },
      { q: "Is this compliant?", a: "We source publicly available business data and follow GDPR/CAN-SPAM requirements for B2B outreach." },
      { q: "Can you find niche industries?", a: "That's the point of custom scrapers — if the data exists publicly, we can build a pipeline for it." },
    ],
  },
  "svc-outreach": {
    process: [
      { step: "Offer Engineering", desc: "We sharpen the message and offer before a single email is sent." },
      { step: "Infrastructure", desc: "Domains, warmup, SPF/DKIM/DMARC and inbox rotation configured for deliverability." },
      { step: "AI Personalisation", desc: "Each prospect's site is analysed so every first line is specific and real." },
      { step: "Iterate", desc: "Weekly A/B tests on subject, angle and CTA against reply-rate data." },
    ],
    deliverables: ["Warmed sending infrastructure", "AI personalisation engine", "Multi-step sequences", "Reply handling playbook", "Weekly performance report"],
    pricing: [
      { tier: "Pilot", price: "$1.5K/mo", blurb: "Prove the channel", items: ["1,000 contacts/mo", "2 sequences", "Deliverability setup"] },
      { tier: "Engine", price: "$3.6K/mo", blurb: "Full outbound motion", items: ["5,000 contacts/mo", "AI personalisation", "A/B testing"], featured: true },
      { tier: "Enterprise", price: "Custom", blurb: "Multi-market outbound", items: ["Unlimited sequences", "SDR enablement", "CRM integration"] },
    ],
    faq: [
      { q: "Will this hurt our domain?", a: "No — we send from dedicated secondary domains with proper warmup, never your primary." },
      { q: "What reply rates should we expect?", a: "Well-targeted campaigns land between 4% and 11% positive reply rate depending on market." },
      { q: "Do you book the meetings?", a: "We hand off warm replies with context; managed reply handling is available on Enterprise." },
    ],
  },
  "svc-ai-auto": {
    process: [
      { step: "Workflow Mapping", desc: "We shadow your operations and document every repetitive, rule-based task." },
      { step: "Agent Design", desc: "Scope, tone, guardrails and escalation rules defined before anything ships." },
      { step: "Build & Train", desc: "Agents grounded in your real docs, pricing and policies — not generic answers." },
      { step: "Monitor", desc: "Transcript review, accuracy scoring and continuous tuning after launch." },
    ],
    deliverables: ["Automation map", "Trained AI agent", "Booking + follow-up flows", "Escalation rules", "Transcript dashboard"],
    pricing: [
      { tier: "Assistant", price: "$1.2K setup", blurb: "Website chatbot", items: ["Trained on your content", "Lead capture", "Email handoff"] },
      { tier: "Receptionist", price: "$2.8K setup", blurb: "24/7 front desk", items: ["Booking + calendar", "FAQ + qualification", "CRM sync"], featured: true },
      { tier: "Operations", price: "Custom", blurb: "Multi-agent systems", items: ["Internal + external agents", "Tool use", "Human escalation"] },
    ],
    faq: [
      { q: "Will it make things up?", a: "Agents are grounded in your approved content with strict fallbacks — unknown questions escalate to a human." },
      { q: "Which tools does it connect to?", a: "Calendars, CRMs, helpdesks, SMS and email — anything with an API." },
      { q: "How long to launch?", a: "A trained website assistant is live in about two weeks; full operations builds run 4–8 weeks." },
    ],
  },
  "svc-social": {
    process: [
      { step: "Channel Strategy", desc: "Where your audience actually is, and what format wins there." },
      { step: "Content Engine", desc: "Templates, hooks and a repurposing pipeline that turns one asset into ten." },
      { step: "Autopilot Scheduling", desc: "Cross-platform posting queues with optimal timing per channel." },
      { step: "Engagement Loops", desc: "Automated replies, DM routing and community triage that keeps momentum." },
    ],
    deliverables: ["Channel strategy", "Content calendar", "Repurposing pipeline", "Auto-scheduling", "Engagement reporting"],
    pricing: [
      { tier: "Queue", price: "$800/mo", blurb: "Never go quiet", items: ["2 channels", "12 posts/mo", "Scheduling + analytics"] },
      { tier: "Autopilot", price: "$2.2K/mo", blurb: "Full content engine", items: ["4 channels", "30 posts/mo", "Repurposing + engagement"], featured: true },
      { tier: "Brand", price: "Custom", blurb: "Multi-brand teams", items: ["Unlimited channels", "Approval workflows", "Dedicated strategist"] },
    ],
    faq: [
      { q: "Do you create the content?", a: "Yes — from your assets, products and expertise, edited into channel-native formats." },
      { q: "Does automation look robotic?", a: "Not when it's built well. Everything is reviewed and scheduled; automation handles timing, not personality." },
      { q: "Which platforms?", a: "Instagram, LinkedIn, TikTok, Facebook, X, YouTube Shorts and Google Business Profile." },
    ],
  },
  "svc-voice": {
    process: [
      { step: "Use-Case Scoping", desc: "Which calls or commands the agent owns, and where a human takes over." },
      { step: "Voice & Script Design", desc: "Persona, tone, latency targets and conversation trees built for real speech." },
      { step: "Integration", desc: "Telephony, calendars and CRM connected so the agent can actually act." },
      { step: "Live Tuning", desc: "Call recordings reviewed weekly to sharpen accuracy and handling." },
    ],
    deliverables: ["Voice persona", "Conversation flows", "Telephony setup", "CRM + calendar actions", "Call transcript analytics"],
    pricing: [
      { tier: "Inbound", price: "$2.5K setup", blurb: "Answer every call", items: ["24/7 call answering", "Message capture", "Call summaries"] },
      { tier: "Agent", price: "$5.5K setup", blurb: "Book and act", items: ["Live booking", "CRM updates", "Warm transfers"], featured: true },
      { tier: "Copilot", price: "Custom", blurb: "Screen-aware assistant", items: ["Desktop control", "Multi-tool automation", "Custom wake commands"] },
    ],
    faq: [
      { q: "Does it sound human?", a: "Modern voice models with sub-second latency — most callers don't realise until told." },
      { q: "What happens if it can't help?", a: "It transfers to a human with a full context summary, or takes a message and schedules a callback." },
      { q: "Can it handle multiple languages?", a: "Yes, including mid-call language switching for bilingual markets." },
    ],
  },
  "svc-workflows": {
    process: [
      { step: "Process Audit", desc: "Every handoff, spreadsheet and copy-paste step documented and costed in hours." },
      { step: "System Design", desc: "A single source of truth defined across CRM, email, calendar and billing." },
      { step: "Pipeline Build", desc: "Automations built with retries, logging and failure alerts — not fragile zaps." },
      { step: "Team Enablement", desc: "Documentation and training so your team owns the system confidently." },
    ],
    deliverables: ["Process map", "Automation pipelines", "Error alerting", "Runbook documentation", "Team training session"],
    pricing: [
      { tier: "Single Flow", price: "$1.4K", blurb: "Fix one bottleneck", items: ["1 workflow", "2 integrations", "Documentation"] },
      { tier: "Stack", price: "$4.8K", blurb: "Connect the business", items: ["Up to 6 workflows", "CRM + billing + comms", "Monitoring"], featured: true },
      { tier: "Operations", price: "Custom", blurb: "Company-wide systems", items: ["Unlimited workflows", "Custom middleware", "Ongoing ops support"] },
    ],
    faq: [
      { q: "Which platforms do you build on?", a: "n8n, Make, Zapier or custom code — chosen for reliability and your team's ability to maintain it." },
      { q: "What if a workflow fails?", a: "Every pipeline has retry logic, logging and alerting so failures are visible and recoverable." },
      { q: "How much time will we save?", a: "Clients typically reclaim 15–40 hours a month per automated process. We quantify it in the audit." },
    ],
  },
  "svc-content": {
    process: [
      { step: "Asset Inventory", desc: "Everything you own catalogued, tagged and deduplicated in one vault." },
      { step: "Vault Architecture", desc: "Permissions, naming conventions and version control that scale with the team." },
      { step: "AI Generation", desc: "On-brand drafts, variations and captions produced from your existing material." },
      { step: "Repurposing Engine", desc: "One long-form asset automatically fanned out across every channel." },
    ],
    deliverables: ["Central content vault", "Tagging taxonomy", "Brand voice profile", "AI generation workflows", "Repurposing automations"],
    pricing: [
      { tier: "Vault", price: "$1.6K", blurb: "Get organised", items: ["Asset migration", "Taxonomy + permissions", "Team onboarding"] },
      { tier: "Engine", price: "$3.4K/mo", blurb: "Vault + production", items: ["AI content generation", "Repurposing flows", "Monthly reporting"], featured: true },
      { tier: "Studio", price: "Custom", blurb: "Full content ops", items: ["Editorial calendar", "Approval workflows", "Dedicated producer"] },
    ],
    faq: [
      { q: "Will AI content sound generic?", a: "We train on your existing best-performing material and every piece passes human review." },
      { q: "Where does the vault live?", a: "Your cloud, your ownership — we architect and automate it, you keep the keys." },
      { q: "Can it handle video?", a: "Yes, including automated clipping, captioning and vertical reformatting." },
    ],
  },
  "svc-analytics": {
    process: [
      { step: "Question Framing", desc: "We start from the decisions you need to make, then work backwards to metrics." },
      { step: "Tracking Plan", desc: "Events, properties and attribution defined and implemented correctly." },
      { step: "Warehouse & Modelling", desc: "Sources unified so every number in the dashboard reconciles." },
      { step: "Dashboards", desc: "Role-specific views with alerts on the numbers that actually matter." },
    ],
    deliverables: ["Tracking plan", "Event implementation", "Attribution model", "Executive dashboard", "Automated reporting"],
    pricing: [
      { tier: "Setup", price: "$1.9K", blurb: "Trustworthy data", items: ["GA4 + events", "Conversion tracking", "QA + documentation"] },
      { tier: "Dashboard", price: "$4.6K", blurb: "Unified reporting", items: ["Multi-source pipeline", "Custom dashboards", "Alerting"], featured: true },
      { tier: "Intelligence", price: "Custom", blurb: "Full data stack", items: ["Warehouse + modelling", "Cohort + LTV analysis", "Ongoing analyst"] },
    ],
    faq: [
      { q: "Why don't our numbers match?", a: "Usually attribution windows and duplicate events. The tracking plan resolves it and we document why each source differs." },
      { q: "Which tools do you use?", a: "GA4, Segment/Rudderstack, BigQuery and Looker Studio or Metabase — matched to your budget and scale." },
      { q: "Is this privacy compliant?", a: "Yes — consent-aware tracking with server-side options where regulations require it." },
    ],
  },
  "svc-maintenance": {
    process: [
      { step: "Onboarding Audit", desc: "Security, dependencies, backups and hosting reviewed and documented." },
      { step: "Hardening", desc: "Patching, firewall rules, uptime monitoring and offsite backups configured." },
      { step: "Monthly Care", desc: "Updates, health checks, content edits and a plain-English report." },
      { step: "Rapid Response", desc: "Priority channel for incidents with defined response windows." },
    ],
    deliverables: ["Security hardening", "Automated backups", "Uptime monitoring", "Monthly health report", "Priority support channel"],
    pricing: [
      { tier: "Care", price: "$180/mo", blurb: "Keep it healthy", items: ["Updates + backups", "Uptime monitoring", "Monthly report"] },
      { tier: "Care+", price: "$490/mo", blurb: "Support included", items: ["2 hours edits/mo", "Security scanning", "48h response"], featured: true },
      { tier: "Managed", price: "Custom", blurb: "Mission critical", items: ["SLA response", "Staging environment", "Dedicated engineer"] },
    ],
    faq: [
      { q: "Do you maintain sites you didn't build?", a: "Yes, after an onboarding audit that establishes a clean, documented baseline." },
      { q: "What's your response time?", a: "48 hours on Care+, and same-day contractual SLAs on Managed plans." },
      { q: "Are backups really offsite?", a: "Daily encrypted offsite snapshots with tested restores — untested backups don't count." },
    ],
  },
  "svc-mobile": {
    process: [
      { step: "Product Definition", desc: "Core loop, platform choice and store requirements agreed before design." },
      { step: "Native-Feel Design", desc: "Platform-appropriate patterns, gestures and haptics — not a wrapped website." },
      { step: "Build & Test", desc: "TestFlight and Play internal builds shipped weekly for real device feedback." },
      { step: "Store Launch", desc: "Listing assets, review submission, and post-launch crash monitoring." },
    ],
    deliverables: ["App source code", "iOS + Android builds", "Store listing assets", "Crash + analytics setup", "Release pipeline"],
    pricing: [
      { tier: "MVP", price: "$12K", blurb: "Validate the idea", items: ["Core feature set", "Both platforms", "Store submission"] },
      { tier: "Product", price: "$28K", blurb: "Full-featured app", items: ["Auth + payments", "Push notifications", "Offline support"], featured: true },
      { tier: "Scale", price: "Custom", blurb: "Complex systems", items: ["Native modules", "Real-time features", "Ongoing roadmap"] },
    ],
    faq: [
      { q: "Native or cross-platform?", a: "React Native or Expo for most products; fully native when hardware or performance demands it." },
      { q: "Do you handle App Store review?", a: "Yes — submission, review responses and resubmissions are included through to approval." },
      { q: "How long to launch?", a: "An MVP typically reaches the stores in 8–12 weeks." },
    ],
  },
  "svc-api": {
    process: [
      { step: "Systems Mapping", desc: "Every tool, data owner and sync direction documented before we write code." },
      { step: "Contract Design", desc: "Schemas, auth model, versioning and rate limits agreed with all stakeholders." },
      { step: "Implementation", desc: "Typed endpoints, validation, idempotency and retry-safe webhooks." },
      { step: "Documentation", desc: "Interactive docs and a sandbox so partners can integrate without hand-holding." },
    ],
    deliverables: ["Integration map", "REST/GraphQL API", "Webhook infrastructure", "Interactive documentation", "Monitoring + alerting"],
    pricing: [
      { tier: "Connector", price: "$2.6K", blurb: "Link two systems", items: ["1 integration", "Error handling", "Documentation"] },
      { tier: "API", price: "$9K", blurb: "Build your own API", items: ["Full endpoint suite", "Auth + rate limits", "Docs + sandbox"], featured: true },
      { tier: "Middleware", price: "Custom", blurb: "Enterprise systems", items: ["Legacy adapters", "Queue architecture", "SLA monitoring"] },
    ],
    faq: [
      { q: "Can you integrate legacy systems?", a: "Yes — SOAP, flat-file, SFTP and database-level adapters included when modern APIs don't exist." },
      { q: "How do you handle failures?", a: "Idempotent operations, dead-letter queues and alerting so nothing silently disappears." },
      { q: "Do you provide documentation?", a: "Always. Interactive OpenAPI docs plus a sandbox environment ship with every API build." },
    ],
  },
}
