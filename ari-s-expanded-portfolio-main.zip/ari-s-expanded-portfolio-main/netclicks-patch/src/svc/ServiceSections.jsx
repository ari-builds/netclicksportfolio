import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Check, Plus, ChevronRight } from "lucide-react"

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.07, type: "spring", stiffness: 200, damping: 24 },
  }),
}

export function SectionHeading({ eyebrow, title, subtitle, color }) {
  return (
    <motion.div
      variants={fadeUp}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-60px" }}
      className="text-center mb-14"
    >
      {eyebrow && (
        <span
          className="inline-block px-3 py-1 rounded-full text-xs font-medium border mb-4"
          style={{ backgroundColor: `${color}15`, color, borderColor: `${color}30` }}
        >
          {eyebrow}
        </span>
      )}
      <h2 className="text-3xl md:text-5xl font-bold mb-4">{title}</h2>
      {subtitle && <p className="text-zinc-400 max-w-2xl mx-auto">{subtitle}</p>}
    </motion.div>
  )
}

export function ProcessTimeline({ steps, color, title = "How we work", subtitle }) {
  return (
    <section className="py-20 md:py-28 px-4">
      <div className="max-w-5xl mx-auto">
        <SectionHeading eyebrow="Process" title={title} subtitle={subtitle} color={color} />
        <div className="relative">
          <div
            className="absolute left-[19px] md:left-1/2 top-2 bottom-2 w-px md:-translate-x-px"
            style={{ background: `linear-gradient(180deg, ${color}00, ${color}55, ${color}00)` }}
          />
          <div className="space-y-8">
            {steps.map((s, i) => (
              <motion.div
                key={s.step}
                custom={i}
                variants={fadeUp}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, margin: "-60px" }}
                className={`relative flex gap-6 md:gap-10 md:items-center ${
                  i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                <div className="md:w-1/2 md:text-right flex-1">
                  <div className={`${i % 2 === 0 ? "md:pr-10" : "md:pl-10 md:text-left"} pl-14 md:pl-0`}>
                    <div className="text-xs font-mono mb-2" style={{ color }}>
                      {String(i + 1).padStart(2, "0")}
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-1.5">{s.step}</h3>
                    <p className="text-sm text-zinc-400 leading-relaxed">{s.desc}</p>
                  </div>
                </div>
                <motion.div
                  whileHover={{ scale: 1.25 }}
                  className="absolute left-0 md:left-1/2 md:-translate-x-1/2 top-1 w-10 h-10 rounded-full border flex items-center justify-center backdrop-blur-sm"
                  style={{ backgroundColor: `${color}18`, borderColor: `${color}45`, color }}
                >
                  <span className="text-xs font-bold">{i + 1}</span>
                </motion.div>
                <div className="hidden md:block md:w-1/2 flex-1" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export function Deliverables({ items, color, title = "What lands in your inbox" }) {
  return (
    <section className="py-20 md:py-28 px-4" style={{ backgroundColor: `${color}05` }}>
      <div className="max-w-5xl mx-auto">
        <SectionHeading eyebrow="Deliverables" title={title} color={color} />
        <div className="flex flex-wrap justify-center gap-3">
          {items.map((item, i) => (
            <motion.div
              key={item}
              custom={i}
              variants={fadeUp}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
              whileHover={{ y: -4 }}
              className="flex items-center gap-2.5 px-5 py-3 rounded-full border bg-zinc-900/60 text-sm text-zinc-200"
              style={{ borderColor: `${color}30` }}
            >
              <Check className="w-4 h-4 shrink-0" style={{ color }} />
              {item}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export function PricingTiers({ tiers, color, onSelect, title = "Simple, scoped pricing" }) {
  return (
    <section className="py-20 md:py-28 px-4">
      <div className="max-w-6xl mx-auto">
        <SectionHeading
          eyebrow="Pricing"
          title={title}
          subtitle="Fixed scope, fixed price. No surprise invoices."
          color={color}
        />
        <div className="grid md:grid-cols-3 gap-5">
          {tiers.map((t, i) => (
            <motion.div
              key={t.tier}
              custom={i}
              variants={fadeUp}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
              whileHover={{ y: -8 }}
              className="relative p-7 rounded-2xl border bg-zinc-900/50 flex flex-col"
              style={{
                borderColor: t.featured ? `${color}60` : `${color}20`,
                boxShadow: t.featured ? `0 25px 50px -20px ${color}55` : "none",
              }}
            >
              {t.featured && (
                <span
                  className="absolute -top-3 left-7 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider text-white"
                  style={{ backgroundColor: color }}
                >
                  Most popular
                </span>
              )}
              <div className="text-sm font-semibold text-zinc-300">{t.tier}</div>
              <div className="mt-2 text-3xl font-bold text-white">{t.price}</div>
              <p className="mt-2 text-sm text-zinc-500">{t.blurb}</p>
              <ul className="mt-6 space-y-2.5 flex-1">
                {t.items.map((it) => (
                  <li key={it} className="flex items-start gap-2 text-sm text-zinc-400">
                    <Check className="w-4 h-4 mt-0.5 shrink-0" style={{ color }} />
                    {it}
                  </li>
                ))}
              </ul>
              <button
                onClick={onSelect}
                className="mt-7 inline-flex items-center justify-center gap-2 w-full py-2.5 rounded-full text-sm font-semibold transition-all hover:opacity-90"
                style={
                  t.featured
                    ? { backgroundColor: color, color: "#fff" }
                    : { border: `1px solid ${color}40`, color }
                }
              >
                Get started <ChevronRight className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export function FAQ({ items, color, title = "Questions, answered" }) {
  const [open, setOpen] = useState(0)
  return (
    <section className="py-20 md:py-28 px-4" style={{ backgroundColor: `${color}05` }}>
      <div className="max-w-3xl mx-auto">
        <SectionHeading eyebrow="FAQ" title={title} color={color} />
        <div className="space-y-3">
          {items.map((f, i) => (
            <motion.div
              key={f.q}
              custom={i}
              variants={fadeUp}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
              className="rounded-2xl border bg-zinc-900/50 overflow-hidden"
              style={{ borderColor: open === i ? `${color}45` : `${color}20` }}
            >
              <button
                onClick={() => setOpen(open === i ? -1 : i)}
                className="w-full flex items-center justify-between gap-4 px-6 py-5 text-left"
              >
                <span className="text-sm md:text-base font-medium text-white">{f.q}</span>
                <motion.span animate={{ rotate: open === i ? 45 : 0 }} style={{ color }}>
                  <Plus className="w-5 h-5" />
                </motion.span>
              </button>
              <AnimatePresence initial={false}>
                {open === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.28, ease: "easeInOut" }}
                  >
                    <p className="px-6 pb-5 text-sm text-zinc-400 leading-relaxed">{f.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
