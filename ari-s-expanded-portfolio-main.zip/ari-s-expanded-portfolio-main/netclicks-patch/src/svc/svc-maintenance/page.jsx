import ServicePage from "../ServicePage"
import { services } from "../ServiceConfig"
import { serviceExtras } from "../ServiceExtras"
import { ProcessTimeline, Deliverables, PricingTiers, FAQ } from "../ServiceSections"

const service = services.find(s => s.slug === "svc-maintenance")
const extras = serviceExtras["svc-maintenance"]

export default function MaintenancePage() {
  const c = service.color
  const scrollToCta = () => document.getElementById("demo")?.scrollIntoView({ behavior: "smooth" })
  return (
    <ServicePage service={service}>
      <ProcessTimeline steps={extras.process} color={c} subtitle={`Our proven ${service.title.toLowerCase()} engagement, step by step.`} />
      <Deliverables items={extras.deliverables} color={c} />
      <PricingTiers tiers={extras.pricing} color={c} onSelect={scrollToCta} />
      <FAQ items={extras.faq} color={c} />
    </ServicePage>
  )
}
