# NetClicks — dedicated service pages patch

These files drop straight into `ari-builds/netclicksportfolio`, keeping the same
paths. Nothing else on the site is touched.

## What's included

New:
- `src/svc/ServiceExtras.js` — per-service process, deliverables, pricing, FAQ content (all 17 services)
- `src/svc/ServiceSections.jsx` — animated Process timeline, Deliverables, Pricing and FAQ sections (framer-motion)
- `src/svc/<slug>/page.jsx` — one dedicated page module per service (17 files)
- `src/svc/pages.js` — slug → page component map

Modified:
- `src/svc/ServicePage.jsx` — now accepts `children`, rendered just above the final CTA
- `src/svc/index.js` — re-exports `servicePages`
- `src/App.jsx` — adds `<Route path="/services/:slug" />` (scrolls to top, renders the page + `<Footer />`, unknown slugs redirect home)
- `src/components/Services.jsx` — each card now has a `slug` and links to `/services/<slug>`

## Install

```bash
cp -r netclicks-patch/src/. /path/to/netclicksportfolio/src/
cd /path/to/netclicksportfolio
npm install && npm run build
```

Routes (with the `/netclicksportfolio` basename):
`/services/svc-web-design`, `svc-web-dev`, `svc-ecommerce`, `svc-seo`,
`svc-responsive`, `svc-performance`, `svc-leadgen`, `svc-outreach`,
`svc-ai-auto`, `svc-social`, `svc-voice`, `svc-workflows`, `svc-content`,
`svc-analytics`, `svc-maintenance`, `svc-mobile`, `svc-api`.

Verified with `npm run build` (exit 0) and a browser pass over
`/services/svc-seo` — no console errors.
