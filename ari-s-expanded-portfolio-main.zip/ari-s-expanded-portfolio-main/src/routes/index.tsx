import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NetClicks Service Pages — Handoff" },
      {
        name: "description",
        content:
          "Seventeen dedicated NetClicks service pages, ready to drop into the netclicksportfolio repository.",
      },
      { property: "og:title", content: "NetClicks Service Pages — Handoff" },
      {
        property: "og:description",
        content:
          "Seventeen dedicated NetClicks service pages, ready to drop into the netclicksportfolio repository.",
      },
    ],
  }),
  component: Index,
});

const slugs = [
  ["svc-web-design", "Web Design"],
  ["svc-web-dev", "Web Development"],
  ["svc-ecommerce", "E-Commerce"],
  ["svc-seo", "SEO Optimization"],
  ["svc-responsive", "Responsive Design"],
  ["svc-performance", "Performance"],
  ["svc-leadgen", "Lead Generation"],
  ["svc-outreach", "AI Outreach Campaigns"],
  ["svc-ai-auto", "AI Automation"],
  ["svc-social", "Social Media Autopilot"],
  ["svc-voice", "AI Voice Agent"],
  ["svc-workflows", "Business Automation Workflows"],
  ["svc-content", "Content Vault & Management"],
  ["svc-analytics", "Analytics Dashboards"],
  ["svc-maintenance", "Website Maintenance & Support"],
  ["svc-mobile", "Mobile App Development"],
  ["svc-api", "API & Integration Development"],
];

function Index() {
  return (
    <main className="min-h-screen bg-background px-6 py-20">
      <div className="mx-auto max-w-3xl">
        <p className="text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground">
          Handoff
        </p>
        <h1 className="mt-3 text-4xl font-bold tracking-tight text-foreground">
          NetClicks service pages
        </h1>
        <p className="mt-4 text-muted-foreground">
          Seventeen dedicated service pages were built against your existing
          design system and verified with a production build. The files live in
          this project under{" "}
          <code className="rounded bg-muted px-1.5 py-0.5 text-sm">
            netclicks-patch/
          </code>{" "}
          mirroring your repository paths — copy them into{" "}
          <code className="rounded bg-muted px-1.5 py-0.5 text-sm">src/</code> of
          netclicksportfolio, rebuild, and deploy. See{" "}
          <code className="rounded bg-muted px-1.5 py-0.5 text-sm">
            netclicks-patch/README.md
          </code>
          .
        </p>

        <h2 className="mt-12 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
          New routes
        </h2>
        <ul className="mt-4 grid gap-2 sm:grid-cols-2">
          {slugs.map(([slug, title]) => (
            <li
              key={slug}
              className="rounded-lg border border-border bg-card px-4 py-3"
            >
              <div className="text-sm font-medium text-card-foreground">
                {title}
              </div>
              <code className="text-xs text-muted-foreground">
                /services/{slug}
              </code>
            </li>
          ))}
        </ul>
      </div>
    </main>
  );
}
